Hello Grader! 

To compile my program, you need to include all of these files: 

Map.h 
Map.cpp 
firstMeet.txt 
endOfRegion.txt 
NPC_talks.txt 
fightTalk.txt
mainP3Driver.cpp 
playerClass.h 
playerClass.cpp 
waterClass.h 
waterClass.cpp 
fireClass.h 
fireClass.cpp 
earthClass.h 
earthClass.cpp 
airClass.h 
airClass.cpp 
NormieClass.h 
NormieClass.cpp 
randMaker.h

Since my play button has always worked, and I have only seen the requirement of a "readme.txt" shortly before submitting, 
I'm afraid I can't provide any help if you want a specific command. 
If you are having issues with the command or just getting my game to start, 
and you doubt that I can compile, please email me at aaba6700@colorado.edu. 
I can show you footage before I submitted that shows my code can compile. 

I am sorry that I could not be of more help, I have been reading mainly the requirements from Project3 Create your own pdf, 
and have not looked at the actual submission until, like aforementioned, shortly before I submit it.

However, I hope you can compile, and that you enjoy my game! 