#include <iostream>
#include <string>
#include <vector>   
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "waterClass.cpp"
#include "fireClass.cpp"
#include "earthClass.cpp"
#include "airClass.cpp"
using namespace std;

/*Each segment of this game will follow the same format:
There will be/is a begin function, then I will add another function that will be the main function 
used for the game (it will be the menu options and make use of the Map class), as well as an end class- 
and anything in between. Between submitting this code skeleton and the due date, there will be most likely
more functions/helper functions, as well as a combat class (still unsure if I have to do a whole class or 
just a function but the former's the current plan).*/

//I need to declare four seperate players, because you cannot declare a 
//person of class playerClass in an if statment and then use it later on

waterClass PlayerA = waterClass();
playerClass Player_A = playerClass();

fireClass PlayerB = fireClass();
playerClass Player_B = playerClass();

earthClass PlayerC = earthClass();
playerClass Player_C = playerClass();

airClass PlayerD = airClass();
playerClass Player_D = playerClass();

void begin(string& name, string& tribeName);
string setTribe(int& choice, string Pname);
void introduction(string name);
void test();
//will be more functions here soon

int main(){
    string name = "";
    string tribeName = "";
    test();
    // I commented this out because I didn't need it for the code skeleton test; however, if you uncomment this and comment 
    //away my test function, it will still compile
    // begin(name, tribeName);
    // introduction(name);
    return 0;
}
void begin(string& name, string& tribeName){ //my begin function, sets the stage for the whole game
    int option;
    cout << endl << endl;
    cout << "Hello there! Welcome to Elenorm!" << endl;
    cout << "Now, what shall we call you?" << endl;
    getline(cin, name);
    cout << "Hello, " << name << "! What tribe would you like to play as?" << endl;
    cout << "1. Water" << endl << "2. Fire" << endl << "3. Earth" << endl << "4. Air" << endl << "5. Random!" << endl;
    cin >> option;
    tribeName = setTribe(option, name);
    cout << "Welcome, " << name << " of the " << tribeName << ", to Ele Island!" << endl;
}

string setTribe(int& choice, string Pname){ //helper function, sets the names and the class I'll use for the player
    
    if (choice == 5){
        srand(time(NULL));
        choice = rand() % 4 + 1;
    }

    if(choice <= 4 && choice >= 1){
        if(choice == 1){
            waterClass PlayerA = waterClass();
            PlayerA.setName(Pname);
            Player_A.setName(Pname);
            return "Water Tribe";
        }
        else if(choice == 2){  
            fireClass PlayerB = fireClass();
            PlayerB.setName(Pname);
            Player_B.setName(Pname);
            return "Fire Nation";
        }
        else if(choice == 3){
            earthClass PlayerC = earthClass();
            PlayerC.setName(Pname);
            Player_C.setName(Pname);
            return "Earth Kingdom";
        }
        else if(choice == 4){
            airClass PlayerD = airClass();
            PlayerD.setName(Pname);
            Player_D.setName(Pname);
            return "Air Nomads";
        }
    }
    return "error";

}
//this is getting ridicuously long and tedious. I will probably just write my own file (dialogue) 
//and then just write a function read it and print it out. 


void introduction(string name){
    cout << endl;
    cout << "And now our game begins..." << endl;   
    cout << endl;
    cout << "It's dark. Very dark. Almost a whole week it's been like this- those angry clouds covering up the trying sun. " << endl;
    cout << "You start to think that maybe this was all for nothing, maybe you should've stayed home, but right then a";
    cout << " crewmate yells 'Land Ahoy!' " << endl << "Your first thought is- 'Do they really say that? The next thought, half formed, barely ";
    cout << "makes it out (We've made it!) before you see Ele Island, looming in the" << endl << "distance." << endl;
    cout << "..." << endl;

    cout << "You step off the boat, more than eager to get off the barely held together tub when one of the locals addresses you:" << endl;
    cout << "Weird old 'granpa': Well ahoy there, " << name << ", how are you doing?" << endl;
    cout << "You: Wait how did you know my na- " << endl;
    cout << "Old Grandpa: Just answer the question!" << endl;
    cout << "You: *A little ataken back* Oh, well, um, I'm just here to get my mastery." << endl;
    cout << "Weird Old 'granpa':  *Slowly turns around and starts walking away* ";
    cout << "Harrumph! I see. Good luck with that boyo..... good luck...." << endl;
    cout << "You: Wait hold up! How did you know my name? And what do you mean good luck?";
    cout << ", you say to no avail, as the old man seemingly dissapeared into the few shadows ";
    cout << "of" << endl << "the brightly lit dock." << endl << "..." << endl;
}

//my test case function that tests every single memeber function, both in the playerClass and the four classes/"tribes"
void test(){
    waterClass Katarra = waterClass("Katarra", 35, 30, 30); 
    playerClass Player1 = playerClass("Katarra", 1);
    cout << Katarra.getPower() << endl;
    cout << Katarra.getHealth() << endl;
    cout << Katarra.getAttack() << endl;
    cout << Katarra.getDefense() << endl;

    //tests my player class/my inheritence from that to water
    Katarra.setHealth(35);
    Katarra.setAttack(35);
    Katarra.setDefense(30);

    cout << Katarra.getName() << endl;
    cout << Katarra.getPower() << endl;
    cout << Katarra.getHealth() << endl;
    cout << Katarra.getAttack() << endl;
    cout << Katarra.getDefense() << endl;

    cout << endl;
    cout << Player1.getTribe() << endl;
    cout << endl;

    cout << Katarra.tsunami() << endl;
    cout << Katarra.iceSpikes() << endl;
    cout << Katarra.hose() << endl;

    cout << "..." << endl;
    fireClass Zuko = fireClass("Zuko", 35, 30, 30);
    playerClass Player2 = playerClass("Zuko", 2);
    cout << Zuko.getPower() << endl;
    cout << Zuko.getHealth() << endl;
    cout << Zuko.getAttack() << endl;
    cout << Zuko.getDefense() << endl;
    

    //tests my player class/my inheritence from that to fire
    Zuko.setHealth(45);
    Zuko.setAttack(40);
    Zuko.setDefense(25);
    cout << endl;
    cout << Zuko.getName() << endl;
    cout << Zuko.getPower() << endl;
    cout << Zuko.getHealth() << endl;
    cout << Zuko.getAttack() << endl;
    cout << Zuko.getDefense() << endl;

    cout << endl;
    cout << Player2.getTribe() << endl;
    cout << endl;

    cout << Zuko.firewall() << endl;
    cout << Zuko.lightningBolt() << endl;
    cout << Zuko.fireball() << endl;

    cout << "..." << endl;
    earthClass Toph = earthClass("Toph", 35, 30, 30);
    playerClass Player3 = playerClass("Toph", 3);
    cout << Toph.getPower() << endl;
    cout << Toph.getHealth() << endl;
    cout << Toph.getAttack() << endl;
    cout << Toph.getDefense() << endl;

    //tests my player class/my inheritence from that to earth
    Toph.setHealth(45);
    Toph.setAttack(40);
    Toph.setDefense(25);
    cout << endl;
    cout << Toph.getName() << endl;
    cout << Toph.getPower() << endl;
    cout << Toph.getHealth() << endl;
    cout << Toph.getAttack() << endl;
    cout << Toph.getDefense() << endl;

    cout << endl;
    cout << Player3.getTribe() << endl;
    cout << endl;

    cout << Toph.theBoulder() << endl;
    cout << Toph.magmaBlast() << endl;
    cout << Toph.gauntlet() << endl;

    cout << "..." << endl;
    airClass Aang = airClass("Aang", 35, 30, 30);
    playerClass Player4 = playerClass("Aang", 4);
    cout << Aang.getPower() << endl;
    cout << Aang.getHealth() << endl;
    cout << Aang.getAttack() << endl;
    cout << Aang.getDefense() << endl;

    //tests my player class/my inheritence from that to air
    Aang.setHealth(45);
    Aang.setAttack(40);
    Aang.setDefense(25);
    cout << endl;
    cout << Aang.getName() << endl;
    cout << Aang.getPower() << endl;
    cout << Aang.getHealth() << endl;
    cout << Aang.getAttack() << endl;
    cout << Aang.getDefense() << endl;

    cout << endl;
    cout << Player4.getTribe() << endl;
    cout << endl;

    cout << Aang.tornado() << endl;
    cout << Aang.windWhip() << endl;
    cout << Aang.airBlast() << endl;

}