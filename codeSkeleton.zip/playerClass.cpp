#include <iostream>
#include <string>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
using namespace std;
#ifndef PLAYERCLASS_H
#define PLAYERCLASS_H
using namespace std;

class playerClass{

protected:
    string name;
    double power;
    double health;
    double attack;
    double defense;

    int upgrade;
    int randomvalue;
    int tribe;

public:
    playerClass();
    playerClass(string n, int t);

    string getTribe();
    void setTribe(int t);
    string getName();
    void setName(string N);
    int getPower();
    void setPower(int P);
    int getHealth();
    void setHealth(int H);
    int getAttack();
    void setAttack(int A);
    int getDefense();
    void setDefense(int D);

};

//player class implementations

playerClass::playerClass(){//default constructor
    name = "Joe Mama"; //funny and it helps debugging
}
playerClass::playerClass(string n, int t){ //paramaterized constructor
    name = n;
    tribe = t;
}
string playerClass::getName(){
    return name;
}
void playerClass::setName(string N){
    name = N;
}
int playerClass::getPower(){
    power = (health + attack + defense) / 3.0;
    return power;
}
void playerClass::setPower(int P){
    power = P;
}
int playerClass::getHealth(){
    return health;
}
void playerClass::setHealth(int H){
    health = H;
}
int playerClass::getAttack(){
    return attack;
}
void playerClass::setAttack(int A){
    attack = A;
}
int playerClass::getDefense(){
    return defense;
}
void playerClass::setDefense(int D){
    defense = D;
}
string playerClass::getTribe(){ //gets the players tribe
    if(tribe == 1){
        return "Water Tribe";
    }
    else if(tribe == 2){
        return "Fire Nation";
    }
    else if(tribe == 3){
        return "Earth Kingdom";
    }
    else if(tribe == 4){
        return "Air Nomads";
    }
    return "error";
}

void playerClass::setTribe(int t){
    tribe = t;
}
#endif