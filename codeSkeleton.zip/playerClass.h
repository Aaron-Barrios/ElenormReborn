#include <iostream>
#include <string>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#ifndef PLAYERCLASS_H
#define PLAYERCLASS_H
using namespace std;

class playerClass{
//there will be plans later on to implement an inventory (most likely a vector of string type),
//but as of yet I haven't been able to hammer out the details before submitting this
protected:
    string name;
    double power;
    double health;
    double attack;
    double defense;

    int upgrade;
    int randomvalue;
    int tribe;

public:
    playerClass();
    playerClass(string n, int t);

    string getTribe();
    void setTribe(int t);
    string getName();
    void setName(string N);
    int getPower();
    void setPower(int P);
    int getHealth();
    void setHealth(int H);
    int getAttack();
    void setAttack(int A);
    int getDefense();
    void setDefense(int D);

};
#endif